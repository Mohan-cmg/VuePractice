<template>
    <div id="app">
        <navbar></navbar>
        <router-view></router-view>
    </div>
</template>

<script>
import Nav from "./components/Navigation.Vue";
export default {
    name: "App",
    components:{
        "navbar":Nav
    }
}
</script>
<template>
    <div>
        <ul>
            <li>
                <router-link to="/" exact> Welcome </rounter-link>
                <rounter-link to="/add" exact> Add </router-link>
                <router-link to="/show" exact> Show </router-link>
            </li>
        </ul>
    </div>
</template>
<script>
export default{    
}
</script>
<template>
    <div>
        Hello {{msg}}
    </div>
</template>
<script>
default export {
    name:"HelloWorld",
    data: function(){
        return {
            msg: "Mohan"
        }
    }
}
</script>
import Welcome from "../components/Welcome.vue"

export default{
    path:"/",
    components: Welcome
}